#!/bin/bash

if [ -f $1 ];
then
 result=`grep -i t $1 | grep p;`
 if [[ ! -z $result ]];
 then
  echo "$1 : $result";
 fi
fi

